package Monpackage;

public class Main {
    public static void main(String[] args) {
        System.out.println("Bonjour, Je vous présente mon premier programme en JAVA !!!" );
        Person P1 =  new Person("Gaelle.payet.univ@gmail.com","8 rue des Fleurs");
        P1.getEmail();
        P1.getAdress();
        System.out.println(P1);

        Creature C1 =  new Creature("Elodie","ALAVIN", "155 cm","45kg", "08/10/1984","elodie.alavin.univ@gmail.com");
        C1.getFirstName();
        C1.getLastName();
        System.out.println("Race : " + C1.getRaces());
        System.out.println(C1);
        Creature C2 = new Creature();

        Cat F1 = new Cat("Persan");
        F1.firstName = "Felix";
        F1.lastName = "LECHAT";
        F1.height = "12/03/1993";
        System.out.println(F1.getFirstName());
        System.out.println("Espece : " + F1.getEspeces());
        // System.out.println("Race : " + C1.getRaces());
        System.out.println(F1);
        System.out.println("Bonjour, Je Suis un chat de type Persan" );






    }






}

