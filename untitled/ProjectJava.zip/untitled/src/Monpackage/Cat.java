package Monpackage;

public class Cat extends Creature {
    public String species;



    public Cat(String species) {
        this.species = species;


    }

    public String getSpecies() {
        return species;
    }

    @Override
    public String toString() {
        return "Cat{" +
                "species='" + species + '\'' +
                '}';
    }

    @Override
    public String getRaces() {
       return null;
    }
}

