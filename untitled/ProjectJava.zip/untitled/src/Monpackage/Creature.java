package Monpackage;

public class Creature implements InterfaceEspece {
    public String firstName;
    public String lastName;
    public String height;
    public String weight;
    public String date;
    public String email;
    public Creature(){

    }

    public Creature (String firstname, String lastname, String height, String weight, String date, String email) {
        this.firstName = firstname;
        this.lastName = lastname;
        this.height = height;
        this.weight = weight;
        this.email = email;
        this.date = date;


    }



    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDate() {
        return date;
    }

    public String getEmail()
    {String email = this.email;

        return email;
    }


    @Override
    public String toString() {
        return "Creature{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", height='" + height + '\'' +
                ", weight='" + weight + '\'' +
                ", date='" + date + '\'' +
                ", email='" + email + '\'' +
                '}';
    }


    @Override
    public String getEspeces() {
        return this.getClass().getSimpleName();
    }

    @Override
    public String getRaces() {
        return this.getClass().getSimpleName();
    }
}




