package Monpackage;

public class Person extends Creature {
    public String email;
    public String adress;

    public Person() {

    }

    public Person (String email, String adress) {

        this.email = email;
        this.adress = adress;
    }
    public String getEmail() {
        return email;
    }

    public String getAdress() {
        return adress;
    }


    @Override
    public String toString() {
        return "Person{" +
                "email='" + email + '\'' +
                ", adress='" + adress + '\'' +
                '}';
    }


}
