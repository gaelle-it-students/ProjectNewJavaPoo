package Monpackage;

public interface InterfaceEspece {
    public String getEspeces();
    public String getRaces();
}
