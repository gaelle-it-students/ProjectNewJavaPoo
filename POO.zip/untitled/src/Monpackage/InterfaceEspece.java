package Monpackage;
// Création Interface pour figer obligatoirement les méthodes à appliquer
public interface InterfaceEspece {
    public String getEspeces();
    public String getRaces();
}
